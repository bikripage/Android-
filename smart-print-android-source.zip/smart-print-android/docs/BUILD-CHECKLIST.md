# Build and test checklist

- [ ] Node.js LTS installed
- [ ] `npm install` successful
- [ ] `npm run build` successful
- [ ] Capacitor Android generated
- [ ] Plugin registered and package names verified
- [ ] App launches and login works
- [ ] Firestore live jobs load
- [ ] PeerJS signaling works on mobile network and Wi-Fi
- [ ] Local WebRTC job receive tested
- [ ] Image print preview/system printer tested
- [ ] PDF support implemented/tested (not included in reference bridge)
- [ ] Auto-accept behavior tested carefully
- [ ] Android back navigation and lifecycle tested
- [ ] Firebase security rules reviewed
